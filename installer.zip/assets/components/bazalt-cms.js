var bazaltCMS = angular.module("bazalt-cms", [ "ngResource" ]).config([ "$interpolateProvider", function($interpolateProvider) {
    $interpolateProvider.startSymbol("{[").endSymbol("]}");
} ]);

bazaltCMS.addMessages = function(locale, domain, messages) {
    window._locales = window._locales || {};
    window._locales[locale] = messages;
};

bazaltCMS.controller("bazaltGlobalController", [ "$scope", "$rootScope", "languages", function($scope, $rootScope, languages) {
    $rootScope.languages = languages;
} ]);

bazaltCMS.factory("appLoading", [ "$rootScope", function($rootScope) {
    var timer;
    return {
        loading: function() {
            clearTimeout(timer);
            $rootScope.status = "loading";
            if (!$rootScope.$$phase) $rootScope.$apply();
        },
        ready: function(delay) {
            function ready() {
                $rootScope.status = "ready";
                if (!$rootScope.$$phase) $rootScope.$apply();
            }
            clearTimeout(timer);
            delay = delay == null ? 500 : false;
            if (delay) {
                timer = setTimeout(ready, delay);
            } else {
                ready();
            }
        }
    };
} ]);

/**
 * @license HTTP Auth Interceptor Module for AngularJS
 * (c) 2012 Witold Szczerba
 * License: MIT
 */
bazaltCMS.provider("AuthService", function() {
    /**
     * Holds all the requests which failed due to 401 response,
     * so they can be re-requested in future, once login is completed.
     */
    var buffer = [];
    /**
     * Holds a list of functions that define rules for ignoring
     * the addition of requests to the buffer.
     */
    var ignoreUrlExpressions = [];
    /**
     * Adds functions to the `ignoreUrlExpressions` array.
     * The fn function takes a URL as a response as an argument and returns
     * `true` (to ignore the URL) or `false` (to allow the URL). When `true` is
     * returned no other expressions will be tested.
     */
    this.addIgnoreUrlExpression = function(fn) {
        if (angular.isFunction(fn)) {
            ignoreUrlExpressions.push(fn);
        }
        return this;
    };
    /**
     * Executes each of the ignore expressions to determine whether the URL
     * should be ignored.
     * 
     * Example:
     *
     *     angular.module('mod', ['http-auth-interceptor'])
     *       .config(function (authServiceProvider) {
     *         authServiceProvider.addIgnoreUrlExpression(function (response) {
     *           return response.config.url === "/api/auth";
     *         });
     *       });
     */
    this.shouldIgnoreUrl = function(response) {
        var fn, i, j = ignoreUrlExpressions.length;
        for (i = 0; i < j; i++) {
            fn = ignoreUrlExpressions[i];
            if (fn(response) === true) {
                return true;
            }
        }
        return false;
    };
    /**
     * Required by HTTP interceptor.
     * Function is attached to provider to be invisible for regular users of this service.
     */
    this.pushToBuffer = function(config, deferred) {
        buffer.push({
            config: config,
            deferred: deferred
        });
    };
    this.$get = [ "$rootScope", "$injector", function($rootScope, $injector) {
        var $http;
        //initialized later because of circular dependency problem
        function retry(config, deferred) {
            $http = $http || $injector.get("$http");
            $http(config).then(function(response) {
                deferred.resolve(response);
            });
        }
        function retryAll() {
            var i;
            for (i = 0; i < buffer.length; ++i) {
                retry(buffer[i].config, buffer[i].deferred);
            }
            buffer = [];
        }
        return {
            loginConfirmed: function() {
                $rootScope.$broadcast("event:auth-loginConfirmed");
                retryAll();
            }
        };
    } ];
}).config([ "$httpProvider", "AuthServiceProvider", function($httpProvider, AuthServiceProvider) {
    var interceptor = [ "$rootScope", "$q", function($rootScope, $q) {
        function success(response) {
            return response;
        }
        function error(response) {
            if (response.status === 401) {
                var deferred = $q.defer();
                if (!AuthServiceProvider.shouldIgnoreUrl(response)) {
                    AuthServiceProvider.pushToBuffer(response.config, deferred);
                }
                $rootScope.$broadcast("event:auth-loginRequired");
                return deferred.promise;
            }
            // otherwise
            return $q.reject(response);
        }
        return function(promise) {
            return promise.then(success, error);
        };
    } ];
    $httpProvider.responseInterceptors.push(interceptor);
} ]);

bazaltCMS.factory("$session", [ "$rootScope", "$resource", "$location", "AuthService", "$route", function($rootScope, $resource, $location, AuthService, $route) {
    var Session = $resource("/rest.php/app/auth/", {}, {
        get: {
            method: "GET"
        },
        login: {
            method: "POST"
        },
        logout: {
            method: "DELETE"
        }
    });
    Session.prototype.login = function(cb) {
        this.$login({}, function(user) {
            $rootScope.$user = new Session(user);
            AuthService.loginConfirmed();
            $rootScope.$broadcast("event:loginConfirmed");
            $route.reload();
        }, function(err) {
            cb = cb || function() {};
            cb(err);
        });
    };
    Session.prototype.logout = function() {
        this.$logout(function() {
            $rootScope.$user = new Session();
            $location.path("/");
            $route.reload();
        });
    };
    Session.prototype.authorized = function() {
        return this.id != null;
    };
    if (!$rootScope.$user) {
        $rootScope.$user = new Session();
        $rootScope.$user = Session.get(function(user) {
            if (user.authorized()) {
                $rootScope.$broadcast("event:loginConfirmed");
                $route.reload();
            }
        });
    }
    $rootScope.$session = Session;
    return Session;
} ]);

bazaltCMS.directive("compareValidate", function() {
    return {
        restrict: "A",
        require: "ngModel",
        link: function(scope, elm, attrs, ctrl) {
            function validateEqual(myValue, otherValue) {
                if (myValue === otherValue) {
                    ctrl.$setValidity("equal", true);
                    return myValue;
                } else {
                    ctrl.$setValidity("equal", false);
                    return undefined;
                }
            }
            scope.$watch(attrs.compareValidate, function(otherModelValue) {
                validateEqual(ctrl.$viewValue, otherModelValue);
            });
            ctrl.$parsers.unshift(function(viewValue) {
                return validateEqual(viewValue, scope.$eval(attrs.compareValidate));
            });
            ctrl.$formatters.unshift(function(modelValue) {
                return validateEqual(modelValue, scope.$eval(attrs.compareValidate));
            });
        }
    };
});

bazaltCMS.directive("link", [ "$rootScope", function($rootScope) {
    return {
        restrict: "E",
        terminal: true,
        compile: function(element, attr) {
            if (attr.type == "text/x-gettext-translation") {
                var domain = attr.id, url = attr.href;
                Pomo.unescapeStrings = true;
                Pomo.returnStrings = true;
                Pomo.load(url, {
                    translation_domain: domain,
                    format: "po",
                    mode: "ajax"
                }).ready(function() {
                    $rootScope.tr = new Date().getTime();
                    if (!$rootScope.$$phase) {
                        $rootScope.$apply();
                    }
                });
            }
        }
    };
} ]);

bazaltCMS.directive("ckeditor", function() {
    var index = 0;
    return {
        restrict: "A",
        require: "ngModel",
        link: function(scope, element, attrs, ngModel) {
            var expression = attrs.ngModel;
            var el = $(element);
            if (angular.isUndefined(CKEDITOR) || angular.isUndefined(CKEDITOR.instances)) {
                return;
            }
            var instance = CKEDITOR.replace(el.get(0), {
                toolbar_Full: [ {
                    name: "document",
                    items: []
                }, {
                    name: "clipboard",
                    items: [ "Cut", "Copy", "Paste", "PasteText", "PasteFromWord", "-", "Undo", "Redo" ]
                }, {
                    name: "editing",
                    items: [ "Find", "Replace", "-", "SpellChecker", "Scayt" ]
                }, {
                    name: "forms",
                    items: []
                }, {
                    name: "basicstyles",
                    items: [ "Bold", "Italic", "Underline", "Strike", "Subscript", "Superscript" ]
                }, {
                    name: "paragraph",
                    items: [ "NumberedList", "BulletedList", "-", "JustifyLeft", "JustifyCenter", "JustifyRight", "JustifyBlock" ]
                }, {
                    name: "links",
                    items: []
                }, {
                    name: "insert",
                    items: [ "SpecialChar" ]
                }, "/", {
                    name: "styles",
                    items: [ "Styles", "Format", "Font", "FontSize" ]
                }, {
                    name: "colors",
                    items: []
                }, {
                    name: "tools",
                    items: [ "Maximize" ]
                } ],
                uiColor: "#FAFAFA",
                height: "400px",
                width: "100%"
            });
            element.bind("$destroy", function() {
                instance.destroy(false);
            });
            instance.on("instanceReady", function() {
                instance.setData(ngModel.$viewValue);
            });
            instance.on("pasteState", function() {
                //scope.$apply(function() {
                ngModel.$setViewValue(instance.getData());
            });
            ngModel.$render = function(value) {
                instance.setData(ngModel.$viewValue);
            };
            scope.$watch(expression, function(val) {
                if (!instance) return;
                if (scope[expression] == instance.getData()) return;
                instance.setData(ngModel.$viewValue);
            });
            scope.$watch(function() {
                if (!element) {
                    return null;
                }
                return instance.getData();
            }, function(val) {
                ngModel.$setViewValue(instance.getData());
            });
            instance.on("blur", function(e) {
                if (!scope.$$phase) {
                    scope.$apply();
                }
            });
        }
    };
});

bazaltCMS.directive("regexValidate", function() {
    return {
        // restrict to an attribute type.
        restrict: "A",
        // element must have ng-model attribute.
        require: "ngModel",
        // scope = the parent scope
        // elem = the element the directive is on
        // attr = a dictionary of attributes on the element
        // ctrl = the controller for ngModel.
        link: function(scope, elem, attr, ctrl) {
            //get the regex flags from the regex-validate-flags="" attribute (optional)
            var flags = attr.regexValidateFlags || "";
            // create the regex obj.
            var regex = new RegExp(attr.regexValidate, flags);
            // add a parser that will process each time the value is 
            // parsed into the model when the user updates it.
            ctrl.$parsers.unshift(function(value) {
                // test and set the validity after update.
                var valid = regex.test(value);
                ctrl.$setValidity("regexValidate", valid);
                // if it's valid, return the value to the model, 
                // otherwise return undefined.
                return valid ? value : undefined;
            });
            // add a formatter that will process each time the value 
            // is updated on the DOM element.
            ctrl.$formatters.unshift(function(value) {
                // validate.
                ctrl.$setValidity("regexValidate", regex.test(value));
                // return the value or nothing will be written to the DOM.
                return value;
            });
        }
    };
});

bazaltCMS.directive("serverSubmit", [ "$http", function($http) {
    function IllegalArgumentException(message) {
        this.message = message;
    }
    var forEach = angular.forEach, noop = angular.noop;
    return {
        restrict: "A",
        scope: false,
        controller: function($scope, $element, $attrs) {
            var self = this;
            self.formComponents = {};
            self.registerFormComponent = function(name, ngModel) {
                self.formComponents[name] = ngModel;
            };
            self.hasFormComponent = function(name) {
                return self.formComponents[name] != undefined;
            };
            self.getFormComponent = function(name) {
                console.info(self.formComponents[name]);
                return self.formComponents[name];
            };
            /**
             * Every submit should reset the form component, because its possible
             * that the error is gone, but the form is still not valid
             */
            self.resetFormComponentsValidity = function() {
                forEach(self.formComponents, function(component) {
                    component.$setValidity("server", true);
                });
            };
        },
        link: function(scope, element, attrs, ctrl) {
            scope.remoteForm = {
                data: {},
                errors: {},
                result: null,
                target: attrs["target"],
                success: attrs["serverSubmit"],
                method: attrs["method"] || "post"
            };
            if (scope.remoteForm.target == undefined) {
                throw new IllegalArgumentException("target must be defined");
            }
            scope.is_submitting = false;
            element.bind("submit", function() {
                scope.$apply(function() {
                    ctrl.resetFormComponentsValidity();
                    scope.remoteForm.data = {};
                    scope.remoteForm.errors = {};
                    forEach(ctrl.formComponents, function(component) {
                        scope.remoteForm.data[component.$name] = component.$viewValue;
                    });
                    scope.remoteForm.result = null;
                    scope.is_submitting = true;
                    $http({
                        method: scope.remoteForm.method,
                        url: scope.remoteForm.target,
                        data: scope.remoteForm.data
                    }).success(function(result) {
                        scope.is_submitting = false;
                        if (typeof scope[scope.remoteForm.success] == "function") {
                            scope[scope.remoteForm.success](result);
                        }
                    }).error(function(data, status) {
                        scope.is_submitting = false;
                        if (status == 400) {
                            forEach(data, function(errors, name) {
                                if (ctrl.hasFormComponent(name)) {
                                    var component = ctrl.getFormComponent(name);
                                    forEach(errors, function(valid, name) {
                                        component.$setValidity(name, valid);
                                    });
                                    component.$setValidity("server", false);
                                    scope.remoteForm.errors[name] = errors;
                                }
                            });
                        }
                    });
                });
            });
        }
    };
} ]).directive("remoteFormComponent", function() {
    return {
        restrict: "A",
        require: [ "^serverSubmit", "ngModel" ],
        link: function(scope, element, attrs, ctrls) {
            var formCtrl = ctrls[0];
            var ngModel = ctrls[1];
            formCtrl.registerFormComponent(attrs.name, ngModel);
            scope.$watch(function() {
                return ngModel.$viewValue;
            }, function(model) {
                ngModel.$setValidity("server", true);
            });
        }
    };
});

bazaltCMS.directive("translate", [ "$filter", "$interpolate", "$rootScope", function($filter, $interpolate, $rootScope) {
    var translate = $filter("translate");
    return {
        restrict: "A",
        scope: true,
        link: function linkFn(scope, element, attr) {
            attr.$observe("translate", function(translationDomain) {
                scope.translationId = $interpolate(element.text())(scope.$parent);
                if (translationDomain != "") {
                    scope.translationDomain = translationDomain;
                }
            });
            attr.$observe("values", function(interpolateParams) {
                scope.interpolateParams = interpolateParams;
            });
            scope.$watch("translationDomain + interpolateParams", function() {
                element.html(translate(scope.translationId, scope.translationDomain, scope.interpolateParams));
            });
            $rootScope.$watch("tr", function() {
                element.html(translate(scope.translationId, scope.translationDomain, scope.interpolateParams));
            });
        }
    };
} ]);

bazaltCMS.directive("ngUpload", [ "$parse", function($parse) {
    var counter = 0;
    return {
        restrict: "A",
        scope: false,
        link: function(scope, element, attrs) {
            var name = attrs["name"];
            var target = attrs["ngUpload"];
            var model = attrs["model"];
            scope.$watch(function() {
                return attrs["ngUpload"];
            }, function(value) {
                target = value;
            });
            var onChange = function(e) {
                var form = angular.element('<form style="display:none;"></form>');
                //var file = e.target.files !== undefined ? e.target.files[0] : (e.target.value ? { name: e.target.value.replace(/^.+\\/, '') } : null)
                // build iframe
                var iframe = angular.element('<iframe src="javascript:false;" name="iframe-transport-' + (counter += 1) + '"></iframe>');
                // add iframe to app
                form.attr("accept-charset", "UTF-8").prop("target", iframe.prop("name")).prop("action", target).prop("method", "POST");
                // attach function to load event
                iframe.bind("load", function() {
                    var response;
                    // Wrap in a try/catch block to catch exceptions thrown
                    // when trying to access cross-domain iframe contents:
                    try {
                        response = iframe.contents();
                        // Google Chrome and Firefox do not throw an
                        // exception when calling iframe.contents() on
                        // cross-domain requests, so we unify the response:
                        if (!response.length || !response[0].firstChild) {
                            throw new Error();
                        }
                        response = JSON.parse($(response[0].body).text());
                    } catch (e) {
                        response = undefined;
                    }
                    if (!response) {
                        return;
                    }
                    var result = response[name];
                    if (model) {
                        scope.$apply(function() {
                            var fn = $parse(model);
                            fn.assign(scope, result);
                        });
                    }
                    // Fix for IE endless progress bar activity bug
                    // (happens on form submits to iframe targets):
                    frame = angular.element('<iframe src="javascript:false;"></iframe>');
                    form.append(frame);
                    form.remove();
                });
                var clone = element.clone();
                clone.bind("change", onChange);
                element.replaceWith(clone);
                form.append(element).prop("enctype", "multipart/form-data").prop("encoding", "multipart/form-data").append(iframe);
                element = clone;
                form.appendTo("body");
                form.submit();
            };
            element.bind("change", onChange);
        }
    };
} ]);

bazaltCMS.filter("default", function() {
    return function(value, defaultValue) {
        return value ? value : defaultValue;
    };
});

bazaltCMS.value("languages", {
    all: [ {
        title: "English",
        alias: "en"
    } ],
    current: "en"
}).run([ "languages", "$rootScope", function(languages, $rootScope) {
    $(document).keydown(function(e) {
        var shiftNums = {
            "1": "!",
            "2": "@",
            "3": "#",
            "4": "$",
            "5": "%",
            "6": "^",
            "7": "&",
            "8": "*",
            "9": "(",
            "0": ")"
        };
        if (e.ctrlKey && e.altKey) {
            var character = parseInt(String.fromCharCode(e.which).toLowerCase());
            if (character > 0 && character <= languages.all.length) {
                e.preventDefault();
                languages.current = languages.all[character - 1].alias;
                if (!$rootScope.$$phase) {
                    $rootScope.$apply();
                }
            }
        }
    });
} ]).filter("language", [ "languages", function(languages) {
    return function(value, language) {
        if (typeof value == "undefined" || value == null) {
            return value;
        }
        language = language || languages.current;
        if (!value[language] && value["orig"]) {
            return value[value["orig"]] + " (" + value["orig"] + ")";
        }
        return value[language];
    };
} ]);

"use strict";

/*
 * фильтр для локализации.
 * использование:
 *
 *  обычный текст:
 *  - {{'Привет, мир'|i18n}}
 *    в файле locales.js:
 *    var _locales = { 'ru-ru': { 'Привет, мир': 'Привет, мир' }, 'en-us': { 'Привет, мир': 'Hello, world' } };
 *
 *  переменные:
 *  - {{'%1 яблоко. Весёлый %2'|i18n:'Красное':'мальчик'}}
 *    в файле locales.js:
 *    var _locales = { 'ru-ru': { '%1 яблоко. Весёлый %2': '%1 яблоко. Весёлый %2' }, 'en-us': { '%1 яблоко. Весёлый %2': 'Apple is %1. Happy %2' } };
 *
 *  склонения:
 *  - {{'Всего %1 яблоко в %2 корзине'|i18n:'plural':4:'моей'}}
 *    в файле locales.js:
 *    var _locales = {
 *        'ru-ru': {
 *            'Всего %1 яблоко в %2 корзине': [
 *                'Всего %1 яблоко в %2 корзине',
 *                'Всего %1 яблока в %2 корзине',
 *                'Всего %1 яблок в %2 корзине'
 *            ]
 *        },
 *        'en-us': {
 *            'Всего %1 яблоко в %2 корзине': [
 *                'There is %1 apple in %2 basket',
 *                'There are %1 apples in %2 basket',
 *            ]
 *        }
 *    }
 *
 *  в js:
 *  - $filter('i18n')('Строка в js');
 *    в файле locales.js:
 *    var _locales = { 'ru-ru': { 'Строка в js': 'Строка в js' }, 'en-us': { 'Строка в js': 'String in js' } };
 *
 *  - $filter('i18n')('Текущая локаль: %1', $locale.id);
 *    var _locales = { 'ru-ru': { 'Текущая локаль: %1': 'Текущая локаль: %1' }, 'en-us': { 'Текущая локаль: %1': 'Current locale: %1' } };
 *
 */
bazaltCMS.filter("translate", [ "$locale", function($locale) {
    return function(str, domain) {
        try {
            var tr = Pomo.getText(str, {
                domain: domain
            });
        } catch (e) {
            return str;
        }
        return tr || str;
        var offset = 1;
        if (arguments[1] && arguments[1] === "plural") {
            var n = arguments[2], plural;
            switch ($locale.id) {
              case "en-us":
              case "de-de":
              case "es-es":
                plural = 0 + (n != 1);
                break;

              case "ru-ru":
                plural = n % 10 == 1 && n % 100 != 11 ? 0 : n % 10 >= 2 && n % 10 <= 4 && (n % 100 < 10 || n % 100 >= 20) ? 1 : 2;
                break;

              case "ar":
                plural = n == 0 ? 0 : n == 1 ? 1 : n == 2 ? 2 : n % 100 >= 3 && n % 100 <= 10 ? 3 : n % 100 >= 11 ? 4 : 5;

              default:
                plural = 0 + (n != 1);
            }
            if (_locales[$locale.id][str]) {
                str = _locales[$locale.id][str][plural] || str;
            }
            offset = 2;
        } else if (typeof _locales[$locale.id][str] != "undefined") {
            str = _locales[$locale.id][str];
        }
        for (var i = offset; i < arguments.length; i++) {
            str = str.split("%" + (i - offset + 1)).join(arguments[i]);
        }
        return str;
    };
} ]);