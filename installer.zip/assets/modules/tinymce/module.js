define(['tinymce/jquery.tinymce', 'tinymce/tiny_mce'], function () {

});