define(['bootstrap-image-gallery/bootstrap-image-gallery.min'], function() {

});